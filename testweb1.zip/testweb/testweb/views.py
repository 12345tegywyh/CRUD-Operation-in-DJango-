from django.shortcuts import render
import pymysql
from .models import EmpOperations
from pymongo import MongoClient

def home(request):
    dic={}
    dic['developer']='Vaishnavi'
    dic['company']='Spider Projects One'
    return render(request,"index.html",dic)

def login(request):
    page=None

    if request.method=="POST":
        id=request.POST.get("uid")
        ps=request.POST.get("psw")
        obj=EmpOperations()
        page=obj.checkuser(id,ps)
        request.session['user']=id

    return render(request,page)

def newemp(request):
    return render(request,"NewEmp.html")

def addemp(request):
    msg=None
    if request.method=="POST":
         try:
             no=int(request.POST.get("employeeNumber"))
             nm=request.POST.get("employeeName")
             dp=request.POST.get("department")
             lo=request.POST.get("location")
             po=request.POST.get("post")
             sl=float(request.POST.get("salary"))
             obj=EmpOperations()
             msg=obj.addnewemp(no,nm,dp,lo,po,sl)
         except:
             msg="Error in insert"    

         dic={}
         dic['status']=msg   

         return render(request,"NewEmpStatus.html",dic)
    
def searchno(request):
    dic={}
    if request.method=='POST':
        try:
            no=int(request.POST.get("employeeNumber"))
            obj=EmpOperations()
            dic=obj.searchno(no)
        except:
            print('error in search data')

    return render(request,"SearchResult.html",dic)

def allemp(request):
    obj=EmpOperations()
    data=obj.getallemp()
    user=request.session['user']
    return render(request,"ShowReport.html",{'empdata':data,'userid':user})
      
def updsal(request):
    return render(request,"updatesalary.html")

def changesal(request):
    dic={}
    if request.method=="POST":
        try:
            no=int(request.POST.get("employeeNumber"))
            sal=float(request.POST.get("newSalary"))
            obj=EmpOperations()
            msg=obj.changesalary(no,sal)
            dic['status']=msg
        except:
            print('error')
            dic['status']='error in update'
    return render(request,"UpdateSalaryStatus.html",dic)

def delemp(request):         
    return render(request,"DeleteEmp.html")

def delete(request):
    dic={}
    if request.method=="POST":
        try:
            no=int(request.POST.get("employeeid1"))
            obj=EmpOperations()
            msg=obj.deleteemp(no)
            dic['status']=msg
        except Exception as e:
            print('e')  
            dic['status']='error in a delete'

    return render(request, "Deletestatus.html",dic)     


def elist(request):
    dic={}
    if request.method=="GET":
        loc=request.GET.get("loc")
        dic['location']=loc

    return render(request,"EmpLocationList.html",dic)


def searchfilm(request):
    return render(request,"searchfilm.html")  


def searchfilmonid(request):
    if request.method=="POST": 
        fid=request.POST.get("filmid")
        dic={}
        dic["_id"]=fid
        print(dic)
        client=MongoClient("mongodb+srv://nawalkarvaishnavi12:vaishnavi3105@vaishnavicluster.b3hvcgi.mongodb.net/?retryWrites=true&w=majority&appName=VaishnaviCluster")
        db=client["ashwinidb"]         
        coll=db["films"]
        film_data = coll.find_one(dic)

        return render(request,"searchfilm.html", {"film": film_data})   
    else:
        return render(request,"searchfilm.html",dic)
        
    
       
def newfilm(request):
    return render(request,"NewFilm.html")


def addfilm(request):
    msg=None
    if request.method=="POST":
         try:
             fid=int(request.POST.get("filmid"))
             fnm=request.POST.get("filmnm")
             yr=request.POST.get("year")
             dir=request.POST.get("Director")
             ib=request.POST.get("imdbrating")
             act=request.POST.get("actor")
             actre=request.POST.get("actress")
             dic={}
             dic['_id']=fid
             dic['fnm']=fnm
             dic['yr']=yr
             dic['dir']=dir
             dic['ib']=ib
             dic['act']=act
             dic['actre']=actre
             print(dic)
             client=MongoClient("mongodb+srv://nawalkarvaishnavi12:vaishnavi3105@vaishnavicluster.b3hvcgi.mongodb.net/?retryWrites=true&w=majority&appName=VaishnaviCluster")
             db=client['ashwinidb']
             coll=db['Films']
             film_data = coll.find_one(dic)

             return render(request,"NewFilm.html", {"film": film_data})
             obj=EmpOperations()
             msg=obj.addnewfilm()
         except:
             msg="Error in insert"    

         
         dic['status']=msg   

         return render(request,"NewFilmStatus.html",dic)
    
    
